import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseGuards,
  Query,
} from '@nestjs/common';
import { ApasService } from './apas.service';
import { CreateApaDto } from './dto/create-apa.dto';
import { UpdateApaDto } from './dto/update-apa.dto';
import {
  ApiBearerAuth,
  ApiCreatedResponse,
  ApiOkResponse,
  ApiParam,
  ApiTags,
} from '@nestjs/swagger';
import { Apa } from './domain/apa';
import { AuthGuard } from '@nestjs/passport';
import {
  InfinityPaginationResponse,
  InfinityPaginationResponseDto,
} from '../utils/dto/infinity-pagination-response.dto';
import { infinityPagination } from '../utils/infinity-pagination';
import { FindAllApasDto } from './dto/find-all-apas.dto';

@ApiTags('Apas')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'))
@Controller({
  path: 'apas',
  version: '1',
})
export class ApasController {
  constructor(private readonly apasService: ApasService) {}

  @Post()
  @ApiCreatedResponse({
    type: Apa,
  })
  create(@Body() createApaDto: CreateApaDto) {
    return this.apasService.create(createApaDto);
  }

  @Get()
  @ApiOkResponse({
    type: InfinityPaginationResponse(Apa),
  })
  async findAll(
    @Query() query: FindAllApasDto,
  ): Promise<InfinityPaginationResponseDto<Apa>> {
    const page = query?.page ?? 1;
    let limit = query?.limit ?? 10;
    if (limit > 50) {
      limit = 50;
    }

    return infinityPagination(
      await this.apasService.findAllWithPagination({
        paginationOptions: {
          page,
          limit,
        },
      }),
      { page, limit },
    );
  }

  @Get(':id')
  @ApiParam({
    name: 'id',
    type: String,
    required: true,
  })
  @ApiOkResponse({
    type: Apa,
  })
  findById(@Param('id') id: string) {
    return this.apasService.findById(id);
  }

  @Patch(':id')
  @ApiParam({
    name: 'id',
    type: String,
    required: true,
  })
  @ApiOkResponse({
    type: Apa,
  })
  update(@Param('id') id: string, @Body() updateApaDto: UpdateApaDto) {
    return this.apasService.update(id, updateApaDto);
  }

  @Delete(':id')
  @ApiParam({
    name: 'id',
    type: String,
    required: true,
  })
  remove(@Param('id') id: string) {
    return this.apasService.remove(id);
  }
}
