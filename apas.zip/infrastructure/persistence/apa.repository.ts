import { DeepPartial } from '../../../utils/types/deep-partial.type';
import { NullableType } from '../../../utils/types/nullable.type';
import { IPaginationOptions } from '../../../utils/types/pagination-options';
import { Apa } from '../../domain/apa';

export abstract class ApaRepository {
  abstract create(
    data: Omit<Apa, 'id' | 'createdAt' | 'updatedAt'>,
  ): Promise<Apa>;

  abstract findAllWithPagination({
    paginationOptions,
  }: {
    paginationOptions: IPaginationOptions;
  }): Promise<Apa[]>;

  abstract findById(id: Apa['id']): Promise<NullableType<Apa>>;

  abstract findByIds(ids: Apa['id'][]): Promise<Apa[]>;

  abstract update(
    id: Apa['id'],
    payload: DeepPartial<Apa>,
  ): Promise<Apa | null>;

  abstract remove(id: Apa['id']): Promise<void>;
}
