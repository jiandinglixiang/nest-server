import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { ApaSchema, ApaSchemaClass } from './entities/apa.schema';
import { ApaRepository } from '../apa.repository';
import { ApaDocumentRepository } from './repositories/apa.repository';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: ApaSchemaClass.name, schema: ApaSchema },
    ]),
  ],
  providers: [
    {
      provide: ApaRepository,
      useClass: ApaDocumentRepository,
    },
  ],
  exports: [ApaRepository],
})
export class DocumentApaPersistenceModule {}
