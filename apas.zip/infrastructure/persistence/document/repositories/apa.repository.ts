import { Injectable } from '@nestjs/common';
import { NullableType } from '../../../../../utils/types/nullable.type';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { ApaSchemaClass } from '../entities/apa.schema';
import { ApaRepository } from '../../apa.repository';
import { Apa } from '../../../../domain/apa';
import { ApaMapper } from '../mappers/apa.mapper';
import { IPaginationOptions } from '../../../../../utils/types/pagination-options';

@Injectable()
export class ApaDocumentRepository implements ApaRepository {
  constructor(
    @InjectModel(ApaSchemaClass.name)
    private readonly apaModel: Model<ApaSchemaClass>,
  ) {}

  async create(data: Apa): Promise<Apa> {
    const persistenceModel = ApaMapper.toPersistence(data);
    const createdEntity = new this.apaModel(persistenceModel);
    const entityObject = await createdEntity.save();
    return ApaMapper.toDomain(entityObject);
  }

  async findAllWithPagination({
    paginationOptions,
  }: {
    paginationOptions: IPaginationOptions;
  }): Promise<Apa[]> {
    const entityObjects = await this.apaModel
      .find()
      .skip((paginationOptions.page - 1) * paginationOptions.limit)
      .limit(paginationOptions.limit);

    return entityObjects.map((entityObject) =>
      ApaMapper.toDomain(entityObject),
    );
  }

  async findById(id: Apa['id']): Promise<NullableType<Apa>> {
    const entityObject = await this.apaModel.findById(id);
    return entityObject ? ApaMapper.toDomain(entityObject) : null;
  }

  async findByIds(ids: Apa['id'][]): Promise<Apa[]> {
    const entityObjects = await this.apaModel.find({ _id: { $in: ids } });
    return entityObjects.map((entityObject) =>
      ApaMapper.toDomain(entityObject),
    );
  }

  async update(
    id: Apa['id'],
    payload: Partial<Apa>,
  ): Promise<NullableType<Apa>> {
    const clonedPayload = { ...payload };
    delete clonedPayload.id;

    const filter = { _id: id.toString() };
    const entity = await this.apaModel.findOne(filter);

    if (!entity) {
      throw new Error('Record not found');
    }

    const entityObject = await this.apaModel.findOneAndUpdate(
      filter,
      ApaMapper.toPersistence({
        ...ApaMapper.toDomain(entity),
        ...clonedPayload,
      }),
      { new: true },
    );

    return entityObject ? ApaMapper.toDomain(entityObject) : null;
  }

  async remove(id: Apa['id']): Promise<void> {
    await this.apaModel.deleteOne({ _id: id });
  }
}
