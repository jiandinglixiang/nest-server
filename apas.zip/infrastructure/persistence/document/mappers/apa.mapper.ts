import { Apa } from '../../../../domain/apa';
import { UserMapper } from '../../../../../users/infrastructure/persistence/document/mappers/user.mapper';

import { ApaSchemaClass } from '../entities/apa.schema';

export class ApaMapper {
  public static toDomain(raw: ApaSchemaClass): Apa {
    const domainEntity = new Apa();
    if (raw.userID2) {
      domainEntity.userID2 = UserMapper.toDomain(raw.userID2);
    } else if (raw.userID2 === null) {
      domainEntity.userID2 = null;
    }

    if (raw.userID) {
      domainEntity.userID = UserMapper.toDomain(raw.userID);
    } else if (raw.userID === null) {
      domainEntity.userID = null;
    }

    domainEntity.id = raw._id.toString();
    domainEntity.createdAt = raw.createdAt;
    domainEntity.updatedAt = raw.updatedAt;

    return domainEntity;
  }

  public static toPersistence(domainEntity: Apa): ApaSchemaClass {
    const persistenceSchema = new ApaSchemaClass();
    if (domainEntity.userID2) {
      persistenceSchema.userID2 = UserMapper.toPersistence(
        domainEntity.userID2,
      );
    } else if (domainEntity.userID2 === null) {
      persistenceSchema.userID2 = null;
    }

    if (domainEntity.userID) {
      persistenceSchema.userID = UserMapper.toPersistence(domainEntity.userID);
    } else if (domainEntity.userID === null) {
      persistenceSchema.userID = null;
    }

    if (domainEntity.id) {
      persistenceSchema._id = domainEntity.id;
    }
    persistenceSchema.createdAt = domainEntity.createdAt;
    persistenceSchema.updatedAt = domainEntity.updatedAt;

    return persistenceSchema;
  }
}
