import { UsersModule } from '../users/users.module';
import { Module } from '@nestjs/common';
import { ApasService } from './apas.service';
import { ApasController } from './apas.controller';
import { DocumentApaPersistenceModule } from './infrastructure/persistence/document/document-persistence.module';

@Module({
  imports: [
    UsersModule,

    // import modules, etc.
    DocumentApaPersistenceModule,
  ],
  controllers: [ApasController],
  providers: [ApasService],
  exports: [ApasService, DocumentApaPersistenceModule],
})
export class ApasModule {}
