import { UsersService } from '../users/users.service';
import { User } from '../users/domain/user';

import { HttpStatus, UnprocessableEntityException } from '@nestjs/common';

import { Injectable } from '@nestjs/common';
import { CreateApaDto } from './dto/create-apa.dto';
import { UpdateApaDto } from './dto/update-apa.dto';
import { ApaRepository } from './infrastructure/persistence/apa.repository';
import { IPaginationOptions } from '../utils/types/pagination-options';
import { Apa } from './domain/apa';

@Injectable()
export class ApasService {
  constructor(
    private readonly userService: UsersService,

    // Dependencies here
    private readonly apaRepository: ApaRepository,
  ) {}

  async create(createApaDto: CreateApaDto) {
    // Do not remove comment below.
    // <creating-property />
    let userID2: User | null | undefined = undefined;

    if (createApaDto.userID2) {
      const userID2Object = await this.userService.findByUser({
        phoneNumber: createApaDto.userID2.id,
      });
      if (!userID2Object) {
        throw new UnprocessableEntityException({
          status: HttpStatus.UNPROCESSABLE_ENTITY,
          errors: {
            userID2: 'notExists',
          },
        });
      }
      userID2 = userID2Object;
    } else if (createApaDto.userID2 === null) {
      userID2 = null;
    }

    let userID: User | null | undefined = undefined;

    if (createApaDto.userID) {
      const userIDObject = await this.userService.findByUser({
        phoneNumber: createApaDto.userID.id,
      });
      if (!userIDObject) {
        throw new UnprocessableEntityException({
          status: HttpStatus.UNPROCESSABLE_ENTITY,
          errors: {
            userID: 'notExists',
          },
        });
      }
      userID = userIDObject;
    } else if (createApaDto.userID === null) {
      userID = null;
    }

    return this.apaRepository.create({
      // Do not remove comment below.
      // <creating-property-payload />
      userID2,

      userID,
    });
  }

  findAllWithPagination({
    paginationOptions,
  }: {
    paginationOptions: IPaginationOptions;
  }) {
    return this.apaRepository.findAllWithPagination({
      paginationOptions: {
        page: paginationOptions.page,
        limit: paginationOptions.limit,
      },
    });
  }

  findById(id: Apa['id']) {
    return this.apaRepository.findById(id);
  }

  findByIds(ids: Apa['id'][]) {
    return this.apaRepository.findByIds(ids);
  }

  async update(
    id: Apa['id'],

    updateApaDto: UpdateApaDto,
  ) {
    // Do not remove comment below.
    // <updating-property />
    let userID2: User | null | undefined = undefined;

    if (updateApaDto.userID2) {
      const userID2Object = await this.userService.findByUser({
        phoneNumber: updateApaDto.userID2.id,
      });
      if (!userID2Object) {
        throw new UnprocessableEntityException({
          status: HttpStatus.UNPROCESSABLE_ENTITY,
          errors: {
            userID2: 'notExists',
          },
        });
      }
      userID2 = userID2Object;
    } else if (updateApaDto.userID2 === null) {
      userID2 = null;
    }

    let userID: User | null | undefined = undefined;

    if (updateApaDto.userID) {
      const userIDObject = await this.userService.findByUser({
        phoneNumber: updateApaDto.userID.id,
      });
      if (!userIDObject) {
        throw new UnprocessableEntityException({
          status: HttpStatus.UNPROCESSABLE_ENTITY,
          errors: {
            userID: 'notExists',
          },
        });
      }
      userID = userIDObject;
    } else if (updateApaDto.userID === null) {
      userID = null;
    }

    return this.apaRepository.update(id, {
      // Do not remove comment below.
      // <updating-property-payload />
      userID2,

      userID,
    });
  }

  remove(id: Apa['id']) {
    return this.apaRepository.remove(id);
  }
}
