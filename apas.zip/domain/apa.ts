import { User } from '../../users/domain/user';
import { ApiProperty } from '@nestjs/swagger';

export class Apa {
  @ApiProperty({
    type: () => User,
    nullable: true,
  })
  userID2?: User | null;

  @ApiProperty({
    type: () => User,
    nullable: true,
  })
  userID?: User | null;

  @ApiProperty({
    type: String,
  })
  id: string;

  @ApiProperty()
  createdAt: Date;

  @ApiProperty()
  updatedAt: Date;
}
